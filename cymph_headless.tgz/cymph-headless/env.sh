#!/bin/bash

# Source setup script for deployments/headless/compose.yaml.
# It also works after being copied to the root of a release bundle as ./env.sh.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/compose.yaml" ] && [ -f "$SCRIPT_DIR/../../env.example" ]; then
    BASE_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
else
    BASE_DIR="$SCRIPT_DIR"
fi

cd "$BASE_DIR" || exit 1

# Define color codes
if command -v tput >/dev/null && [ -t 1 ]; then
    RED=$(tput setaf 1)
    GREEN=$(tput setaf 2)
    YELLOW=$(tput setaf 3)
    BLUE=$(tput setaf 4)
    NC=$(tput sgr0) # No Color
else
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    BLUE='\033[0;34m'
    NC='\033[0m' # No Color
fi

dotenv_replace() {
    local env_var_name=$1
    local new_value=$2
    local file_path=$3

    delimiter="#"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        sed -i '' "s$delimiter^${env_var_name}=.*$delimiter${env_var_name}=${new_value}$delimiter" "$file_path"
    else
        sed -i "s$delimiter^${env_var_name}=.*$delimiter${env_var_name}=${new_value}$delimiter" "$file_path"
    fi
}

file_replace() {
    local old_value=$1
    local new_value=$2
    local file_path=$3

    if [[ "$OSTYPE" == "darwin"* ]]; then
        sed -i '' "s/${old_value}/${new_value}/" "$file_path"
    else
        sed -i "s/${old_value}/${new_value}/" "$file_path"
    fi
}

echo -e "${YELLOW}Creating .env (headless mode)...${NC}"

if ! command -v docker &> /dev/null
then
    echo -e "${RED}Docker could not be found. Please install Docker and try again.${NC}"
    exit
fi

if [ -f .env ]; then
    read -p "A .env file already exists. Do you want to overwrite it? (y/n) " -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Exiting...${NC}"
        exit 0
    fi
fi

env_file=".env"

read -p "On-prem Administrator email: " admin_email
admin_email=${admin_email:-}
regex="^[a-z0-9!#\$%&'*+/=?^_\`{|}~-]+(\.[a-z0-9!#$%&'*+/=?^_\`{|}~-]+)*@([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z0-9]([a-z0-9-]*[a-z0-9])?\$"
if [[ ${admin_email} =~ $regex ]] ; then
    :
else
    echo -e "${RED}Invalid e-mail address. Exiting...${NC}"
    exit 0
fi

echo "CYMPH_ONPREM_ADMIN_EMAIL=${admin_email}" > .dbenv

echo -e "${YELLOW}Generating new auth secret...${NC}"
signing_secret=$(openssl rand -base64 32)

echo -e "${YELLOW}Generating data encryption key..${NC}"
encryption_key=$(docker run --rm python:3.12-slim-bookworm /bin/bash -c "\
    pip install cryptography >/dev/null 2>&1; \
    python -c 'import os; import base64; print(base64.b64encode(os.urandom(48)))'")

echo -e "${YELLOW}Generating data encryption IV..${NC}"
encryption_iv=$(docker run --rm python:3.12-slim-bookworm /bin/bash -c "\
    pip install cryptography >/dev/null 2>&1; \
    python -c 'import os; import base64; print(os.urandom(16).hex())'")

echo -e "${YELLOW}Generating session secret..${NC}"
session_secret=$(docker run --rm python:3.12-slim-bookworm /bin/bash -c "\
    pip install cryptography >/dev/null 2>&1; \
    python -c 'import os; import base64; print(os.urandom(32).hex())'")

echo -e "${YELLOW}Creating new .env from env.example...${NC}"
cp env.example .env

dotenv_replace "NEXTAUTH_SECRET" "$signing_secret" "$env_file"
dotenv_replace "CYMPH_AUTH_SECRET" "$signing_secret" "$env_file"
dotenv_replace "CYMPH_SESSION_SECRET" "$session_secret" "$env_file"

env_mode="production"

read -p "Enter the new IP address or domain (default: localhost): " new_ip
new_ip=${new_ip:-localhost}

read -p "Enter the port (default: 443): " new_port
new_port=${new_port:-443}

dotenv_replace "BIND_PORT" "$new_port" "$env_file"

read -p "Enter the port for call media (TURN over TLS) (default: 5349): " turn_port
turn_port=${turn_port:-5349}
dotenv_replace "NEXT_PUBLIC_LIVEKIT_TURN_TLS_PORT" "$turn_port" "$env_file"
file_replace "server_name test;" "server_name ${new_ip};" nginx/nginx.conf

read -p "Enter the location of the SSL certificate (default: /etc/ssl/bundle.crt): " certificate_location
certificate_location=${certificate_location:-/etc/ssl/bundle.crt}

read -p "Enter the location of the SSL certificate key (default: /etc/ssl/cert.key): " certificate_key_location
certificate_key_location=${certificate_key_location:-/etc/ssl/cert.key}

dotenv_replace "SSL_CERTIFICATE" "$certificate_location" "$env_file"
dotenv_replace "SSL_CERTIFICATE_KEY" "$certificate_key_location" "$env_file"

# External database connection
echo -e "${BLUE}Configure external PostgreSQL connection${NC}"

while true; do
    read -p "External DB host (e.g. db.internal.example.com): " db_host
    if [ -n "$db_host" ]; then
        break
    fi
    echo -e "${RED}Host is required.${NC}"
done

while true; do
    read -p "Require PostgreSQL SSL mode? (y/n, default: n): " postgres_ssl
    postgres_ssl=${postgres_ssl:-n}
    case $postgres_ssl in
        [Yy]* )
            ssl_mode="true"
            break
            ;;
        [Nn]* )
            ssl_mode="false"
            break
            ;;
        * ) echo -e "${RED}Please answer y or n.${NC}";;
    esac
done

dotenv_replace "CYMPH_DB_HOST" "\"$db_host\"" "$env_file"
dotenv_replace "CYMPH_DB_SSL" "$ssl_mode" "$env_file"
dotenv_replace "NODE_ENV" "$env_mode" "$env_file"

dotenv_replace "CYMPH_BACKEND_API_ENDPOINT" "https://${new_ip}:${new_port}" "$env_file"
dotenv_replace "NEXT_PUBLIC_BACKEND_API_ENDPOINT" "https://${new_ip}:${new_port}" "$env_file"

dotenv_replace "NEXTAUTH_URL" "https://${new_ip}:${new_port}" "$env_file"
dotenv_replace "CYMPH_APP_BASE_URL" "https://${new_ip}:${new_port}" "$env_file"
dotenv_replace "NEXT_PUBLIC_WEBAPP_URL" "https://${new_ip}:${new_port}" "$env_file"

dotenv_replace "CYMPH_ENCRYPTION_KEY" "$encryption_key" "$env_file"
dotenv_replace "CYMPH_ENCRYPTION_IV" "$encryption_iv" "$env_file"

# Calls (LiveKit): a key pair for this install, the address browsers use, and the domain of the TURN relay (its port was asked above)
echo -e "${YELLOW}Generating the calls (LiveKit) key pair...${NC}"
livekit_key="cymph$(openssl rand -hex 6)"
livekit_secret=$(openssl rand -hex 32)
dotenv_replace "CYMPH_LIVEKIT_URL" "wss://${new_ip}:${new_port}/livekit" "$env_file"
dotenv_replace "CYMPH_LIVEKIT_API_KEY" "$livekit_key" "$env_file"
dotenv_replace "CYMPH_LIVEKIT_API_SECRET" "$livekit_secret" "$env_file"
dotenv_replace "LIVEKIT_TURN_DOMAIN" "$new_ip" "$env_file"
if [[ $new_ip == "localhost" ]]; then
    echo -e "${YELLOW}Calls need the IP address or domain other machines use to reach this server: with localhost they do not work.${NC}"
else
    echo -e "${YELLOW}Calls carry media over TCP ${turn_port}: open it to this server as well as ${new_port}, and make sure the certificate covers ${new_ip}.${NC}"
fi


echo -e "${GREEN}Environment file created successfully.${NC}"

# Initialize schema on the external DB
echo -e "${BLUE}Answer 'n' only if the external database is already set up and you only want to provide the existing cymph password.${NC}"
read -p "Initialize schema on external DB now? (y/n, default: n): " init_schema
init_schema=${init_schema:-n}
if [[ $init_schema =~ ^[Yy]$ ]]; then
    read -s -p "Password for postgres superuser: " db_admin_password
    echo

    echo -e "${YELLOW}Generating cymph DB password..${NC}"
    cymph_db_password=$(openssl rand -base64 48 | tr -d '+/=' | head -c 32)
    dotenv_replace "CYMPH_DB_PASSWORD" "$cymph_db_password" "$env_file"

    if [[ "$ssl_mode" == "true" ]]; then
        pg_sslmode="require"
    else
        pg_sslmode="prefer"
    fi

    echo -e "${YELLOW}Running db-setup/nuke_and_setup.sh against ${db_host} (sslmode=${pg_sslmode})...${NC}"
    docker run --rm \
        -v "$PWD/db-setup:/db-setup" \
        -w /db-setup \
        -e PGPASSWORD="$db_admin_password" \
        -e PGUSER=postgres \
        -e PGSSLMODE="$pg_sslmode" \
        -e CYMPH_ONPREM_ADMIN_EMAIL="$admin_email" \
        -e CYMPH_DB_PASSWORD="$cymph_db_password" \
        pgvector/pgvector:pg16 \
        bash ./nuke_and_setup.sh "$db_host"

    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Schema initialization complete.${NC}"
    else
        echo -e "${RED}Schema initialization failed. Check the output above.${NC}"
        exit 1
    fi
else
    echo -e "${YELLOW}Skipping schema initialization. Provide the existing cymph role's password so the app can connect.${NC}"
    while true; do
        read -s -p "Password for existing cymph DB role: " existing_cymph_password
        echo
        if [ -n "$existing_cymph_password" ]; then
            break
        fi
        echo -e "${RED}Password is required.${NC}"
    done
    dotenv_replace "CYMPH_DB_PASSWORD" "$existing_cymph_password" "$env_file"
    echo -e "${GREEN}CYMPH_DB_PASSWORD set in .env.${NC}"
fi
