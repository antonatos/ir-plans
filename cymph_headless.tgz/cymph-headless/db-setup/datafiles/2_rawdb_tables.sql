GRANT SELECT ON ALL TABLES IN SCHEMA public TO cymph;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO cymph;

\c rawdb
CREATE EXTENSION IF NOT EXISTS vector;

\c rawdb cymph

CREATE EXTENSION IF NOT EXISTS "citext";

CREATE TABLE role_scope (
    scope TEXT UNIQUE
);

INSERT INTO role_scope VALUES 
  ('org'),
  ('individual');

CREATE TABLE roles (
    role_name text NOT NULL UNIQUE,
    title text NOT NULL,
    scope text NOT NULL REFERENCES role_scope(scope),
    description text NOT NULL
);

INSERT INTO roles(role_name, title, scope, description) VALUES 
    ('role:org_admin', 'Admin', 'org', 'Has full control over the organisation, including managing settings, users and playbooks'), 
    ('role:org_editor', 'Editor', 'org', 'Can create, edit and delete content within the organisation but does not have administrative privileges. Can only share playbooks within the organisation.'), 
    ('role:org_collaborator', 'Collaborator', 'org', 'Can do what the Editor role permits and additionally share playbooks directly, with other organisations and/or publicly'), 
    ('role:org_viewer', 'Viewer', 'org', 'Has read only access to content within the organisation. Can leave comments but cannot create and share playbooks'), 
    ('role:individual', 'Individual Member', 'individual', 'this is the description of individual member');

CREATE TABLE permissions (
    permission_name text NOT NULL unique,
    group_name text NOT NULL, 
    subgroup_name text NOT NULL, 
    description text NOT NULL,
    PRIMARY KEY (permission_name)
);

INSERT INTO permissions(permission_name, group_name, subgroup_name, description) VALUES
 ('org:remove_user', 'User Management Permissions', 'Members', 'Remove user from the organisation'),
 ('org:invite_user', 'User Management Permissions', 'Members', 'Invite users to join the organisation'),
 ('org:assign_role', 'User Management Permissions', 'Members', 'Assign roles to members'),
 ('org:change_user_settings', 'User Management Permissions', 'Members', 'Edit settings for members'),
 ('org:change_settings', 'Organisation Management Permissions', 'Organisation information', 'Change organisation name and visibility status'),
 ('playbooks:create', 'Playbook Permissions', 'Create, Delete & Modify', 'Create, Delete & Edit own playbooks'),
 ('playbooks:delete_org', 'Playbook Permissions', 'Create, Delete & Modify', 'Remove organisation playbooks'),
 ('playbooks:direct_own_org', 'Playbook Permissions', 'Comment & Share', 'Enables sharing directly with a user of your organisation'),
 ('playbooks:direct_other_org', 'Playbook Permissions', 'Comment & Share', 'Enables sharing directly with a user of another organisation'),
 ('playbooks:internal_sharing', 'Playbook Permissions', 'Comment & Share', 'Enables sharing with your organisation'),
 ('playbooks:external_sharing', 'Playbook Permissions', 'Comment & Share', 'Enables sharing with other organisations'),
 ('playbooks:ensemble_sharing', 'Playbook Permissions', 'Comment & Share', 'Enables sharing with a custom group of organisations (including yours)'),
 ('playbooks:public_sharing', 'Playbook Permissions', 'Comment & Share', 'Enables sharing with all registered users'),
 ('playbooks:comment', 'Playbook Permissions', 'Comment & Share', 'Comment on playbooks'),
 ('integrations:manage', 'Integration Management Permissions', 'Create, Delete & Modify', 'Create, Delete & Modify integrations'),
 ('integrations:execute', 'Integration Management Permissions', 'Execute', 'Submit a playbook for execution'),
 ('assets:manage', 'Asset Management Permissions', 'Create, Delete & Modify', 'Create, Delete & Modify assets'),
 ('org:manage_teams', 'Organisation Management Permissions', 'Teams', 'Create, Delete & Modify teams');


CREATE TABLE role_permission_map (
    role_name text NOT NULL REFERENCES roles(role_name) ON DELETE CASCADE,
    permission_name text NOT NULL REFERENCES permissions(permission_name) ON DELETE CASCADE,
    enabled boolean NOT NULL,
    PRIMARY KEY (role_name, permission_name)
);

\copy role_permission_map (role_name, permission_name, enabled) FROM '/docker-entrypoint-initdb.d/permission_map.csv' DELIMITER ',' CSV

CREATE TABLE sectors_specification (
    name text UNIQUE NOT NULL 
);

INSERT INTO sectors_specification VALUES ('cacao'); 
INSERT INTO sectors_specification VALUES ('NIS2'); 

CREATE TABLE sectors (
    id serial UNIQUE,
    name text,
    spec text REFERENCES sectors_specification(name) NOT NULL,
    parent text,
    description text
);

\copy sectors (id, spec, name, parent, description) FROM '/docker-entrypoint-initdb.d/sectors.csv' DELIMITER ',' CSV;

CREATE TABLE features (
    feature_name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL
);

INSERT INTO features(feature_name, description) VALUES 
    ('export:stackstorm', 'Export to Stackstorm (Orquesta format)'),
    ('api:generate_keys', 'Generate and revoke API keys');

CREATE TABLE organizations (
    org_id serial UNIQUE,
    org_name CITEXT UNIQUE NOT NULL,
    date_created timestamp NOT NULL,
    stix_identity text NOT NULL,
    user_limit integer DEFAULT 3,
    profile_pic_url text,
    visible boolean DEFAULT true,
    org_verified boolean DEFAULT false,
    org_url text,
    playbook_limit integer DEFAULT 4
);

CREATE TABLE org_sectors (
    org_id int REFERENCES organizations(org_id) ON DELETE CASCADE,
    sector_id int REFERENCES sectors(id)
);

ALTER SEQUENCE organizations_org_id_seq RESTART WITH 1;

CREATE TABLE teams (
    team_id serial UNIQUE,
    name text NOT NULL,
    date_created timestamp NOT NULL,
    org_id int REFERENCES organizations(org_id) ON DELETE CASCADE NOT NULL,
    PRIMARY KEY (name, org_id)
);

CREATE TABLE users (
    user_id serial,
    name_surname text NOT NULL,
    preferred_name text,
    company_name text,
    job_title text,
    preferred_language text DEFAULT 'en',
    preferred_content_language text DEFAULT 'en',
    date_created timestamp,
    pass VARCHAR(100) NOT NULL,
    email text NOT NULL UNIQUE,
    org_id int REFERENCES organizations(org_id),
    joined_org_at timestamp,
    active boolean DEFAULT true,
    verified boolean DEFAULT false,
    onboarding_complete boolean DEFAULT false,
    terms_accepted boolean DEFAULT false,
    subscribe_enabled boolean DEFAULT false,
    stix_identity text,
    last_pass_change timestamp,
    last_login bigint,
    password_failures int DEFAULT 0,
    last_password_failure timestamp,
    password_history text[] DEFAULT NULL,
    visible boolean DEFAULT false,
    oauth_signup boolean NOT NULL,
    profile_pic_url text,
    token VARCHAR(100),
    playbook_limit integer DEFAULT 4,
    dark_mode boolean DEFAULT false,
    user_verified boolean default false,
    PRIMARY KEY (user_id)
);

CREATE TABLE deleted_users (
    date_deleted timestamp NOT NULL,
    email text NOT NULL
);

CREATE TABLE user_roles (
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    role_name text REFERENCES roles(role_name)
); 

CREATE TABLE user_features (
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    feature text REFERENCES features(feature_name),
    valid_until timestamp NOT NULL
);

CREATE TABLE org_features (
    org_id int REFERENCES organizations(org_id) ON DELETE CASCADE,
    feature text REFERENCES features(feature_name),
    valid_until timestamp NOT NULL
);

CREATE TABLE pending_invites (
    email text NOT NULL UNIQUE,
    sender_user_id int NOT NULL REFERENCES users(user_id),
    personal_message text,
    initial_role text REFERENCES roles(role_name),
    org_id int REFERENCES organizations(org_id) ON DELETE CASCADE,
    skipped boolean DEFAULT false,
    expires timestamp 
);

CREATE TABLE pending_verifications (
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    verification_id uuid NOT NULL UNIQUE,
    email_sent boolean DEFAULT false,
    name_surname TEXT DEFAULT '',
    email TEXT NOT NULL UNIQUE,
    PRIMARY KEY (verification_id)
);


CREATE TABLE user_notification_settings (
    user_id int NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    send_by_email boolean NOT NULL 
);

CREATE TABLE team_members (
    team_id int REFERENCES teams(team_id) ON DELETE CASCADE,
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    PRIMARY KEY (team_id, user_id)
);

CREATE TABLE session (
    sid varchar NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) NOT NULL,
    CONSTRAINT session_pkey PRIMARY KEY (sid) NOT DEFERRABLE INITIALLY IMMEDIATE
) WITH (OIDS=FALSE);
 

CREATE TABLE playbooks (
    id serial UNIQUE,
    owner_id int REFERENCES users(user_id) ON DELETE CASCADE,
    last_updated_by int REFERENCES users(user_id) ON DELETE SET NULL,
    name text NOT NULL,
    date_added timestamp NOT NULL,
    last_updated timestamp NOT NULL,
    description text,
    labels CITEXT ARRAY,
    playbook_types TEXT ARRAY,
    content_id TEXT NOT NULL,
    contents jsonb NOT NULL,
    draft boolean NOT NULL,
    validation_errors int NOT NULL,
    playbook_metadata jsonb DEFAULT NULL
);

CREATE TABLE playbook_template_info (
    id serial UNIQUE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    tags TEXT ARRAY,
    thumbnail_url TEXT,
    content_file TEXT NOT NULL
);

INSERT INTO playbook_template_info(title, description, tags, thumbnail_url, content_file) 
    VALUES ('Blank', 'An empty CACAO v2.0 playbook', NULL, 'templates/blank.png', 'templates/basic_playbook.json');

INSERT INTO playbook_template_info(title, description, tags, thumbnail_url, content_file) 
    VALUES ('Incident response (SANS PICERL model)', 'An incident response playbook based on the SANS PICERL model', ARRAY ['Incident Response'], 'templates/picerl.png', 'templates/incident_response_SANS_PICERL.json');

INSERT INTO playbook_template_info(title, description, tags, thumbnail_url, content_file) 
    VALUES ('Incident response (NIST PDCP model)', 'An incident response playbook based on the NIST PDCP model', ARRAY ['Incident Response'], 'templates/pdcp.png', 'templates/incident_response_NIST_PDCP.json');

CREATE TABLE playbook_direct_shares (
    sharer_user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    playbook_id int REFERENCES playbooks(id) ON DELETE CASCADE,
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    allow_editing BOOLEAN DEFAULT false,
    PRIMARY KEY (playbook_id, user_id)
);

CREATE TABLE playbook_org_shares (
    sharer_user_id int NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    playbook_id int NOT NULL REFERENCES playbooks(id) ON DELETE CASCADE,
    org_id int NOT NULL REFERENCES organizations(org_id) ON DELETE CASCADE,
    allow_editing BOOLEAN DEFAULT false,
    PRIMARY KEY (sharer_user_id, playbook_id, org_id)
);

CREATE TABLE playbook_team_shares (
    sharer_user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    playbook_id int REFERENCES playbooks(id) ON DELETE CASCADE,
    team_id int REFERENCES teams(team_id) ON DELETE CASCADE,
    allow_editing BOOLEAN DEFAULT false,
    PRIMARY KEY (playbook_id, team_id)
);

CREATE TABLE playbook_sector_shares (
    sharer_user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    playbook_id int REFERENCES playbooks(id) ON DELETE CASCADE,
    sector_id int REFERENCES sectors(id) ON DELETE CASCADE,
    allow_editing BOOLEAN DEFAULT false,
    PRIMARY KEY (sharer_user_id, playbook_id, sector_id)
);

CREATE TABLE playbook_public_shares (
    sharer_user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    playbook_id int REFERENCES playbooks(id) ON DELETE CASCADE,
    allow_editing BOOLEAN DEFAULT false,
    PRIMARY KEY (sharer_user_id, playbook_id)
);

CREATE TABLE playbook_comments (
    comment_id serial UNIQUE,
    playbook_id int REFERENCES playbooks(id) ON DELETE CASCADE,
    owner_id int REFERENCES users(user_id),
    reply_to int REFERENCES playbook_comments(comment_id) ON DELETE CASCADE,
    contents text NOT NULL,
    date_created timestamp NOT NULL
);

CREATE TABLE notification_types (
    notification_type TEXT NOT NULL UNIQUE
);

INSERT INTO notification_types VALUES 
    ('notification:user'),
    ('notification:join_org'),
    ('notification:system'),
    ('notification:playbook');

CREATE TABLE user_notifications (
    id serial,
    notification_type TEXT REFERENCES notification_types(notification_type) NOT NULL,
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    source_user int REFERENCES users(user_id) ON DELETE CASCADE,
    ref_playbook int REFERENCES playbooks(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    content text,
    date_created timestamp,
    is_read boolean
);

CREATE TABLE integration_types (
    id serial UNIQUE,
    can_execute boolean NOT NULL,
    can_push boolean NOT NULL,
    name varchar(200) UNIQUE
);

INSERT INTO integration_types(name, can_execute, can_push) VALUES ('soarca', true, true);
INSERT INTO integration_types(name, can_execute, can_push) VALUES ('stackstorm', true, true);

CREATE TABLE integrations (
    id serial UNIQUE, 
    owner_id int REFERENCES users(user_id) ON DELETE CASCADE NOT NULL,
    org_id int REFERENCES organizations(org_id),
    type_id int REFERENCES integration_types(id) NOT NULL,
    name TEXT NOT NULL,
    config jsonb NOT NULL,
    enabled boolean NOT NULL,
    PRIMARY KEY(owner_id, name, type_id)
);

CREATE TABLE execution_history (
    id serial,
    owner_id int REFERENCES users(user_id) ON DELETE CASCADE NOT NULL,
    playbook_name TEXT NOT NULL,
    playbook_contents TEXT NOT NULL, 
    original_playbook TEXT NOT NULL, 
    instance_id INT REFERENCES integrations(id) ON DELETE CASCADE NOT NULL, 
    type_name TEXT REFERENCES integration_types(name) NOT NULL, 
    submitted_timestamp TIMESTAMP NOT NULL,
    finished_timestamp TIMESTAMP,
    execution_specific_data jsonb DEFAULT NULL,
    execution_log TEXT DEFAULT NULL, 
    status TEXT NOT NULL
);

CREATE TABLE ensembles (
    id serial UNIQUE,
    owner_id int REFERENCES users(user_id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    PRIMARY KEY(owner_id, name)
);

CREATE TABLE ensemble_members (
    ensemble_id INT REFERENCES ensembles(id) ON DELETE CASCADE NOT NULL,
    org_id int REFERENCES organizations(org_id) ON DELETE CASCADE NOT NULL
);

CREATE TABLE asset_categories (
    id serial UNIQUE,
    name TEXT NOT NULL
);

INSERT INTO asset_categories(id, name) VALUES (0, 'People and Places');
INSERT INTO asset_categories(id, name) VALUES (1, 'Devices and Equipment');
INSERT INTO asset_categories(id, name) VALUES (2, 'Others');

CREATE TABLE asset_types (
    id serial UNIQUE,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    display_name TEXT NOT NULL,
    category_id int REFERENCES asset_categories(id) NOT NULL 
);

INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (0, 'group', 'A group object that is used for commands that need to be processed or executed by a group', 'Group', 0);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (1, 'individual', 'An individual object that is used for commands that need to be processed or executed by an individual', 'Individual', 0);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (2, 'location', 'A location object that is used for commands that need to be processed or executed by or at a location', 'Location', 0);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (3, 'organization', 'An organization object that is used for commands that need to be processed or executed by an organization', 'Organization', 0);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (4, 'sector', 'A sector object that is used for commands that need to be processed or executed by a sector', 'Sector', 0);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (5, 'http-api', 'An HTTP API object that is used for commands that need to be processed or executed by an HTTP API', 'HTTP API', 1);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (6, 'linux', 'A Linux system object that is used for commands that need to be processed or executed by a Linux system', 'Linux', 1);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (7, 'net-address', 'A network address object that is used for commands that need to be processed or executed by a device at a network address', 'Network Address', 1);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (8, 'security-category', 'A security (infrastructure) category object that is used for commands that need to be processed or executed by a piece of security infrastructure', 'Security infrastructure', 1);
INSERT INTO asset_types (id, name, description, display_name, category_id) VALUES (9, 'ssh', 'A SSH CLI object that is used for commands that need to be processed or executed by an SSH CLI', 'SSH', 1);

CREATE TABLE asset_share_status (
    status TEXT UNIQUE
);

INSERT INTO asset_share_status VALUES ('Private');
INSERT INTO asset_share_status VALUES ('Shared');
INSERT INTO asset_share_status VALUES ('Public');

CREATE TABLE assets (
    id serial UNIQUE,
    owner_id int REFERENCES users(user_id) ON DELETE CASCADE,
    asset_uuid TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    type_id int REFERENCES asset_types(id) NOT NULL,
    date_added TIMESTAMP NOT NULL,
    last_updated TIMESTAMP NOT NULL,
    share_status TEXT REFERENCES asset_share_status(status) NOT NULL,
    contents jsonb NOT NULL,
    labels CITEXT ARRAY,
    PRIMARY KEY(owner_id, name, type_id)
);

CREATE TABLE assets_org_shares (
    asset_id INT REFERENCES assets(id) ON DELETE CASCADE NOT NULL,
    org_id INT REFERENCES organizations(org_id) ON DELETE CASCADE NOT NULL,
    PRIMARY KEY(asset_id, org_id)
);

CREATE TABLE assets_public_shares (
    asset_id INT REFERENCES assets(id) ON DELETE CASCADE NOT NULL,
    PRIMARY KEY(asset_id)
);

CREATE TABLE user_assets_favorites (
    favorite_id serial UNIQUE,
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    asset_id int REFERENCES assets(id) ON DELETE CASCADE,
    PRIMARY KEY(user_id, asset_id)
);

CREATE TABLE authinfo_types (
    id serial UNIQUE,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    display_name TEXT NOT NULL
);

INSERT INTO authinfo_types (id, name, description, display_name) VALUES (0, 'http-basic', 'This type defines the HTTP basic authentication information object and is used by agents and targets when performing HTTP basic authentication.', 'HTTP Basic Authentication');
INSERT INTO authinfo_types (id, name, description, display_name) VALUES (1, 'oauth2', 'This type defines the Oauth2 authentication information object and is used by agents and targets when performing oauth2 authentication', 'OAuth2 Authentication');
INSERT INTO authinfo_types (id, name, description, display_name) VALUES (2, 'user-auth', 'This type defines a generic username / password authentication information object and is used by agents and targets when performing authentication', 'User Authentication');

CREATE TABLE authinfo_share_status (
    status TEXT UNIQUE
);

INSERT INTO authinfo_share_status VALUES ('Private');
INSERT INTO authinfo_share_status VALUES ('Shared');

CREATE TABLE authinfo (
    id serial UNIQUE,
    owner_id int REFERENCES users(user_id) ON DELETE CASCADE,
    authinfo_uuid TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    type_id int REFERENCES authinfo_types(id) NOT NULL,
    date_added TIMESTAMP NOT NULL,
    last_updated TIMESTAMP NOT NULL,
    share_status TEXT REFERENCES authinfo_share_status(status) NOT NULL,
    contents jsonb NOT NULL,
    labels CITEXT ARRAY,
    PRIMARY KEY(owner_id, name, type_id)
);

CREATE TABLE authinfo_org_shares (
    authinfo_id INT REFERENCES authinfo(id) ON DELETE CASCADE NOT NULL,
    org_id INT REFERENCES organizations(org_id) ON DELETE CASCADE NOT NULL,
    PRIMARY KEY(authinfo_id, org_id)
);

CREATE TABLE user_authinfo_favorites (
    favorite_id serial UNIQUE,
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    authinfo_id int REFERENCES authinfo(id) ON DELETE CASCADE,
    PRIMARY KEY(user_id, authinfo_id)
);

CREATE TABLE user_favorites (
    favorite_id serial UNIQUE,
    user_id int REFERENCES users(user_id) ON DELETE CASCADE,
    playbook_id int REFERENCES playbooks(id) ON DELETE CASCADE,
    PRIMARY KEY(user_id, playbook_id)
);

CREATE TABLE user_last_opened (
    user_id int NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    playbook_id int NOT NULL REFERENCES playbooks(id) ON DELETE CASCADE,
    time_opened timestamp NOT NULL,
    PRIMARY KEY (user_id, playbook_id)
);

CREATE TABLE password_reset_tokens (
    email VARCHAR(36) NOT NULL,    
    token uuid NOT NULL UNIQUE,
    token_expiry timestamp NOT NULL,    
    PRIMARY KEY (email, token)
);

CREATE TABLE api_keys (
    id serial UNIQUE, 
    user_id int NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    key_value TEXT NOT NULL UNIQUE,
    date_created timestamp NOT NULL
);

CREATE TABLE schema_info (
    ts timestamp NOT NULL,
    schema_version TEXT NOT NULL
);

INSERT INTO schema_info(ts, schema_version) VALUES (NOW(), 'A.3');

CREATE TABLE data_info (
    ts timestamp NOT NULL,
    data_version TEXT NOT NULL
);

CREATE INDEX idx_session_expire ON session (expire);

CREATE TABLE bug_reports (
    date_created TIMESTAMP NOT NULL,
    title TEXT NOT NULL,
    reporter TEXT NOT NULL,
    product_version TEXT NOT NULL,
    description TEXT NOT NULL,
    tags TEXT ARRAY
);
