\c rawdb cymph

CREATE TABLE licenses (
    date_created TIMESTAMP NOT NULL,
    license_data TEXT NOT NULL
);

INSERT INTO role_scope VALUES ('global');

INSERT INTO roles(role_name, title, scope, description) VALUES 
    ('role:onprem_admin', 'On-prem Admin', 'global', 'Has full control over all organisations and users');

INSERT INTO permissions(permission_name, group_name, subgroup_name, description) VALUES
     ('onprem:manage_orgs', 'On-premises Management Permissions', 'Create, Delete & Modify', 'Create, Delete & Modify organisations'),
     ('onprem:license_update', 'On-premises Management Permissions', 'Licensing', 'Update License');

\copy role_permission_map (role_name, permission_name, enabled) FROM '/docker-entrypoint-initdb.d/permission_map_onprem.csv' DELIMITER ',' CSV

\set admin_email `echo $CYMPH_ONPREM_ADMIN_EMAIL`
INSERT INTO users(user_id, name_surname, date_created, pass, email, verified, last_pass_change, oauth_signup, 
    playbook_limit, stix_identity, onboarding_complete) VALUES
    (1, 'On-prem Administrator', NOW(), '$2a$12$LNgjVm1pLfTqaj6zTAqWRuac.KNYbE80Gy8nT7FD8i3gVx5HEzHVy', :'admin_email', true, 
    to_timestamp(0), false, NULL, 'individual--68ed7be5-429b-436e-98e2-57c399ec13f6', true);

INSERT INTO user_roles(user_id, role_name) VALUES (1, 'role:onprem_admin');

ALTER SEQUENCE users_user_id_seq RESTART WITH 2;

ALTER TABLE users ALTER COLUMN playbook_limit SET DEFAULT NULL;
ALTER TABLE organizations ALTER COLUMN playbook_limit SET DEFAULT NULL;