DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cymph') THEN
    EXECUTE 'GRANT cymph TO ' || quote_ident(current_user);
    EXECUTE 'DROP OWNED BY cymph';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cymph_readonly') THEN
    EXECUTE 'GRANT cymph_readonly TO ' || quote_ident(current_user);
    EXECUTE 'DROP OWNED BY cymph_readonly';
  END IF;
END $$;

DROP DATABASE IF EXISTS rawdb;
DROP ROLE IF EXISTS cymph;
DROP ROLE IF EXISTS cymph_readonly;

CREATE USER cymph WITH PASSWORD 'cymph' CREATEDB;
CREATE DATABASE rawdb OWNER cymph;
--GRANT pg_read_server_files TO cymph;

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO cymph;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO cymph;


CREATE ROLE cymph_readonly LOGIN PASSWORD 'cymph';
GRANT CONNECT ON DATABASE rawdb TO cymph_readonly;
GRANT USAGE ON SCHEMA public TO cymph_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO cymph_readonly;

\c rawdb
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "citext";
