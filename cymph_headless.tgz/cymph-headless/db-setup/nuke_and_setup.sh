#!/bin/bash
set -euo pipefail

DBHOST=${1:-localhost}
export PGUSER="${PGUSER:-postgres}"
CYMPH_DB_PASSWORD="${CYMPH_DB_PASSWORD:-cymph}"

if [[ "$OSTYPE" == "darwin"* ]]; then
    sed_option="-i ''"
else
    sed_option="-i"
fi

psql -h ${DBHOST} -d postgres -c "SELECT pg_terminate_backend(pg_stat_activity.pid) FROM pg_stat_activity WHERE pg_stat_activity.datname in ('rawdb') AND pid <> pg_backend_pid();" || true

cp datafiles/1_creation.sql /tmp/
sed ${sed_option} "s/PASSWORD 'cymph'/PASSWORD '${CYMPH_DB_PASSWORD}'/g" /tmp/1_creation.sql

psql -h ${DBHOST} -d postgres -v ON_ERROR_STOP=1 -f /tmp/1_creation.sql

cp datafiles/permission_map.csv datafiles/permission_map_onprem.csv datafiles/sectors.csv datafiles/2_rawdb_tables.sql datafiles/3_onprem.sql /tmp/

sed ${sed_option} "s/docker-entrypoint-initdb.d/tmp/g" /tmp/2_rawdb_tables.sql
sed ${sed_option} "s/docker-entrypoint-initdb.d/tmp/g" /tmp/3_onprem.sql

PGUSER=cymph PGPASSWORD="${CYMPH_DB_PASSWORD}" psql -h ${DBHOST} -d rawdb -v ON_ERROR_STOP=1 -f /tmp/2_rawdb_tables.sql

PGUSER=cymph PGPASSWORD="${CYMPH_DB_PASSWORD}" psql -h ${DBHOST} -d rawdb -v ON_ERROR_STOP=1 -f /tmp/3_onprem.sql

rm -rf /tmp/1_creation.sql /tmp/sectors.csv /tmp/permission_map.csv /tmp/permission_map_onprem.csv /tmp/2_rawdb_tables.sql /tmp/3_onprem.sql